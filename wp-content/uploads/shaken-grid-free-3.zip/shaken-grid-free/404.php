<?php get_header(); ?>

<div class="wrap">    
    <div id="page">
    	<div class="wide-col">
        	<h2>Sorry, this page wasn't found</h2>
            <?php get_search_form(); ?>
        </div>
        
        <?php get_sidebar(); ?>
	</div><!-- #page -->
</div><!-- #wrap -->
<?php get_footer(); ?>