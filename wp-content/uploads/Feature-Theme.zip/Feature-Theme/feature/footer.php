
<div class="ft-top-border"></div>



 
 
  <div class="ter-btmo">
  <div class="centfootor">
  
  <div class="ccop-cont">
  <div class="copyrights"><?php $ftrcrt= get_option(SHORT_NAME . 'ftrcrt'); echo $ftrcrt; ?> Theme by <a href="http://www.webhostingyes.com">Web Hosting Yes</a> and <a href="http://www.moonthemes.com">Premium Wordpress Themes</a></div>  
</div>


<?php

//                                               IMPORTANT NOTICE

// The links in the footer must remain intact. Those links are my own websites, they are not third party sites
// You can buy the link free version of this theme by cotacting me
// Keeping WebHostingYes.com and MoonThemes.com links at the bottom of the Theme is compulsory in order to use this Premium Wordpress Theme for Free: 
// By violating linking rules you fully be aware of committing Copyright violation, and are in breach of contract. 
// and unquestionably legal action will be taken against. We have tracking system, so we can catch who removes our links 

?>
  
  
  
				   
   
   
  
  </div>
  </div> <!-- end: ter-btmo -->           
 



<?php wp_footer(); ?>


<script type="text/javascript">Cufon.now();</script>
</body>
</html>