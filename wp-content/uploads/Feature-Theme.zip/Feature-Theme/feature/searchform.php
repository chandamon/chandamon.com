
		       <div class="search-main"> <div class="search-box">
<form method="get" id="searchform" action="<?php bloginfo('home'); ?>/">
<input type="text" size="15" class="search-field" name="s" id="s" value="Type..." onfocus="if(this.value == 'Type...') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Type...';}"/>
<input  type="submit" class="search-go" value="" />
</form></div><!-- end: search-box --></div>
	         
