
<div class="sidebar">


	           <div class="logo"><?php the_logo(); ?>
		        </div>
				




	


<div class="sidb-middle">

								<?php 	
if ( !function_exists('dynamic_sidebar') || 
!dynamic_sidebar("Sidebar-Widgets") ) : ?>


<div class="side-cats2">
<div class="sider-22">


<div class="woodo">
Now add some widgets!
</div></div>

</div>
	<?php endif; ?>	


		
</div>

<div class="piodni"></div>
</div>



