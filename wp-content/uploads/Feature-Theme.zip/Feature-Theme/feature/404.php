<?php get_header(); ?>
<?php get_sidebar(); ?>

 <div class="mbo-all">

	<div class="bg-oo">
		<div class="cate-oops">Oops! No Posts Found </div>
		<div class="cate-aeros">Sorry, but you are looking for something that isn't here. </div></div>
</div>

<?php get_footer(); ?>